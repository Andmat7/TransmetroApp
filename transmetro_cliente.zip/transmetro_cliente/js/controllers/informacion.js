render("informacion",{});
$("#informacion").trigger('create');

boton_back ("informacion");